export default function Home() {
  return <main>Inicio</main>;
}
